import os
import sys

sys.path.append(os.path.join(os.path.dirname(__file__), "lib"))

import xbmc
import xbmcaddon

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")


def first_run_setup():
    """
    Execute initial configurations on first installation.
    """
    # Check if this is the first run
    first_run_completed = ADDON.getSetting("first_run_completed")
    
    if first_run_completed == "true":
        return  # Already executed
    
    xbmc.log("[Kodex] First run detected, attempting automatic setup", xbmc.LOGINFO)
    
    # Try to import vstream settings
    settings_imported = False
    try:
        from lib.import_vstream_settings import import_vstream_settings
        settings_imported = import_vstream_settings(auto_mode=True)
    except Exception as e:
        xbmc.log("[Kodex] Failed to import vstream settings: {}".format(str(e)), xbmc.LOGWARNING)
    
    # Try to configure TMDB Helper
    tmdb_configured = False
    try:
        from lib.setup_tmdb_helper import setup_tmdb_helper_player
        tmdb_configured = setup_tmdb_helper_player(auto_mode=True)
    except Exception as e:
        xbmc.log("[Kodex] Failed to setup TMDB Helper: {}".format(str(e)), xbmc.LOGWARNING)
    
    # Mark first run as completed
    ADDON.setSetting("first_run_completed", "true")
    xbmc.log("[Kodex] First run setup completed", xbmc.LOGINFO)
    
    # Show restart dialog if any configuration was done
    if settings_imported or tmdb_configured:
        import xbmcgui
        # Small delay to ensure UI is ready
        xbmc.sleep(500)
        dialog = xbmcgui.Dialog()
        dialog.ok(
            ADDON.getLocalizedString(30015),
            ADDON.getLocalizedString(30016)
        )
        xbmc.log("[Kodex] Closing Kodi...", xbmc.LOGINFO)
        xbmc.executebuiltin("Quit")

# Set to True to enable debugging via pycharm
DEBUG = False

if DEBUG:
    os.environ["PYDEVD_DISABLE_FILE_VALIDATION"] = "1"
    try:
        import pydevd

        xbmc.log("pydevd server is running. start debugging", xbmc.LOGINFO)
        pydevd.settrace(host="127.0.0.1", port=8877, protocol="dap", suspend=False)

    except ImportError:
        xbmc.log("pydevd not imported. not starting debug session", xbmc.LOGWARNING)
    except ConnectionRefusedError:
        xbmc.log("Failed to connect to pycharm", xbmc.LOGERROR)
    except Exception as e:
        xbmc.log(f"Failed to start debug session: {e}", xbmc.LOGERROR)

# Execute initial configuration on first installation
first_run_setup()

# If addon is opened directly (no action/query) — show main menu and open settings
_param_str = sys.argv[2] if len(sys.argv) > 2 else ""
if _param_str in ("", "?"):
    try:
        import xbmcgui
        import xbmcplugin
        
        # Create a simple directory with a settings button
        handle = int(sys.argv[1])
        
        # Add settings item
        list_item = xbmcgui.ListItem("Settings")
        list_item.setArt({'icon': 'DefaultAddonService.png'})
        url = f"plugin://{ADDON_ID}/?action=open_settings"
        xbmcplugin.addDirectoryItem(handle, url, list_item, isFolder=False)
        
        # End directory
        xbmcplugin.endOfDirectory(handle, updateListing=False, cacheToDisc=False)
        
        # Open settings
        xbmc.executebuiltin(f"Addon.OpenSettings({ADDON_ID})")
    except Exception as e:
        xbmc.log(f"Failed to show main menu: {e}", xbmc.LOGWARNING)

if __name__ == "__main__":
    from lib.player import addon_router

    addon_router()
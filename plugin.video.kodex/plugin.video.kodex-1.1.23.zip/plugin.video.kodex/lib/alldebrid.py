from typing import Optional

from .utils import fetch_data, log

def unlock_link(token: str, link: str, timeout: int = 15) -> Optional[str]:
    """
    Use Alldebrid API v4 to unlock a link via the generic fetch_json helper.
    Returns a usable URL string on success, or None on failure.
    """
    if not token or not link:
        return None

    url = "https://api.alldebrid.com/v4/link/unlock"
    headers = {
        "Authorization": f"Bearer {token}"
    }

    resp = fetch_data(url=url, method="POST", data={"link": link}, headers=headers, timeout=timeout)
    log(resp)
    if not resp or not isinstance(resp, dict):
        log("Alldebrid: empty or invalid response")
        return None

    data = resp.get("data") or {}
    if isinstance(data, dict):
        if data.get("link"):
            return data.get("link")

    for k in ("link", "url", "download"):
        if resp.get(k):
            return resp.get(k)

    log("Alldebrid: no usable url in response")
    return None
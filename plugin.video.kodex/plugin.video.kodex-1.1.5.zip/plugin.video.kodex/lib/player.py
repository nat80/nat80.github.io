import os
import sys
from urllib import parse
from typing import Dict
import json
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

from .utils import fetch_kodex, build_url, log
from .alldebrid import unlock_link

ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_HANDLE = int(sys.argv[1])
ADDON_NAME = "Kodex"

def get_streams(params: Dict[str, str]) -> None:
    """
    Fetch and display available video streams based on search parameters.
    
    Args:
        params: Dictionary containing search parameters (tmdb_type, tmdb_id, title, year, etc.)
    """
    log(f"Searching streams with params: {params}")

    # Build title for notification
    title = (f'{params.get("title", "")} ({params.get("year", "")})'
            if params.get("tmdb_type", "") == "movie"
            else params.get("name", ""))

    xbmcgui.Dialog().notification(
        "Recherche en cours...",
        title,
        xbmcgui.NOTIFICATION_INFO,
        2000,
        False
    )

    query_params = {}
    if params.get('season', None) is not None:
        query_params = {'season': params['season']}
    if params.get('episode', None) is not None:
        query_params['episode'] = params['episode']
    if title:
        query_params['query'] = title

    # Include addon setting resolution if configured under 2160p
    max_res = ADDON.getSetting("resolution")
    if max_res is not None and max_res != "2160p":
        query_params["resolution"] = max_res

    # Fetch streams from API
    response = fetch_kodex(f"/search/{params['tmdb_type']}/{params['tmdb_id']}", query_params)
    if not response:
        xbmcgui.Dialog().notification(ADDON_NAME, "Failed to fetch streams", xbmcgui.NOTIFICATION_ERROR)
        return

    # Extract and validate streams data
    streams = response.get("data", {}).get("links", [])
    if not streams:
        xbmcgui.Dialog().notification(ADDON_NAME, "No streams available", xbmcgui.NOTIFICATION_ERROR)
        return

    # if there are only one movie stream or if it is an episode show_playing_release
    if len(streams) == 1 or params.get("tmdb_type") == "tv":
        query_params["show_playing_release"] = True

    # Create list items for each stream
    for stream in streams:
        create_list_item(stream, query_params)

    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def get_poster_image(stream: Dict) -> str:
    """
    Determine which poster image to display based on stream video details.
    
    Args:
        stream: Dictionary containing stream information with video_details
        
    Returns:
        Path to the appropriate poster image
    """
    video_details = stream.get('video_details', {})
    resolution = video_details.get('resolution', '')
    hdr_type = video_details.get('hdrtype', '')
    
    # Dolby Vision takes priority
    if hdr_type == 'dolbyvision':
        image_name = 'dolby_vision.png'
    # 4K with HDR (not Dolby Vision)
    elif resolution == '4k' and hdr_type and hdr_type != 'none':
        image_name = '4k_hdr.png'
    # 4K SDR (no HDR)
    elif resolution == '4k':
        image_name = '4k_sdr.png'
    # 1080p / Full HD
    elif resolution == '1080p' :
        image_name = 'fullhd.png'
    elif resolution == '720p' :
        image_name = 'hd.png'
    # Default fallback
    else:
        image_name = 'kodex_logo.png'
    
    return os.path.join(ADDON_PATH, 'resources', 'media', image_name)


def create_list_item(stream, query_params):
    """
    Create and add a list item for a video stream.
    
    Args:
        stream: Dictionary containing stream information
    """
    release_name = stream.get('release_name', '')
    
    size = stream.get('size', None)
    size_gb : str = str(round(size / (1024 ** 3), 1))+" GB" if size else ""

    # Create list item with video information
    li = xbmcgui.ListItem(label=release_name, offscreen=False)
    tags = li.getVideoInfoTag()
    tags.setTitle(f"{query_params.get('query', '')} - {size_gb}")
    tags.addAudioStream(xbmc.AudioStreamDetail(codec=release_name, channels=0))

    # Set artwork based on video quality
    poster_image = get_poster_image(stream)
    li.setArt({"thumb": poster_image, "poster": poster_image})

    # Mark as playable
    li.setProperty("IsPlayable", "true")

    # Build playback URL
    playback_params = {
        "stream": json.dumps(stream),
        "query_params": json.dumps(query_params)
    }
    log(playback_params)
    playback_url = build_url("play_video", **playback_params)

    xbmcplugin.addDirectoryItem(
        handle=ADDON_HANDLE,
        url=playback_url,
        listitem=li,
        isFolder=False
    )


def play_video(params: Dict[str, str]) -> None:
    """
    Resolve and play a video URL.
    Uses Alldebrid v4 when the addon setting is enabled, otherwise falls back to Kodex proxify endpoint.
    """
    stream = json.loads(params.get("stream", "{}"))
    query_params = json.loads(params.get("query_params", "{}"))

    video_url = None

    # If user enabled Alldebrid, try v4 unlock with provided token
    try:
        use_alldebrid = ADDON.getSetting("use_alldebrid")
    except Exception:
        use_alldebrid = "false"

    if use_alldebrid and use_alldebrid.lower() in ("true", "1", "yes"):
        token = ADDON.getSetting("alldebrid_token") or ""
        if token and stream.get("link"):
            video_url = unlock_link(token, stream.get("link"))
            if video_url:
                log(f"Resolved via Alldebrid: {video_url}")
            else:
                log("Alldebrid did not return a usable URL, falling back to proxify_stream")

    # Fallback to kodex proxify endpoint
    if not video_url:
        resp = fetch_kodex("/proxify_stream", params={"url": stream.get("link")})
        if not resp:
            xbmcgui.Dialog().notification(ADDON_NAME, "Failed to resolve stream", xbmcgui.NOTIFICATION_ERROR)
            return
        video_url = resp.get("data", {}).get("proxied_url")
        if not video_url:
            xbmcgui.Dialog().notification(ADDON_NAME, "Invalid stream URL", xbmcgui.NOTIFICATION_ERROR)
            return

    # Create playable list item and resolve
    li = xbmcgui.ListItem(path=video_url)
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, li)

    if query_params.get("show_playing_release", False):
        xbmcgui.Dialog().notification("Lecture de ...", stream.get("release_name", ""), xbmcgui.NOTIFICATION_INFO, 5000, False)


def addon_router():
    """
    Main routing function that handles addon URLs and dispatches to appropriate handlers.
    """
    # Get URL parameters
    param_string = sys.argv[2][1:]
    if not param_string:
        return

    # Available action handlers
    actions = {
        "get_streams": get_streams,
        "play_video": play_video,
    }

    # Parse parameters and execute action
    params = dict(parse.parse_qsl(param_string))
    if action := params.get("action"):
        if action_func := actions.get(action):
            action_func(params)
            return

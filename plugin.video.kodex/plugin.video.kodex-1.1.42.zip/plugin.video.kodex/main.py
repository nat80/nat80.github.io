import os
import sys

sys.path.append(os.path.join(os.path.dirname(__file__), "lib"))

import xbmc
import xbmcaddon

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")

# Set to True to enable debugging via pycharm
DEBUG = False

if DEBUG:
    os.environ["PYDEVD_DISABLE_FILE_VALIDATION"] = "1"
    try:
        import pydevd

        xbmc.log("pydevd server is running. start debugging", xbmc.LOGINFO)
        pydevd.settrace(host="127.0.0.1", port=8877, protocol="dap", suspend=False)

    except ImportError:
        xbmc.log("pydevd not imported. not starting debug session", xbmc.LOGWARNING)
    except ConnectionRefusedError:
        xbmc.log("Failed to connect to pycharm", xbmc.LOGERROR)
    except Exception as e:
        xbmc.log(f"Failed to start debug session: {e}", xbmc.LOGERROR)

# If addon is opened directly (no action/query) — open settings
_param_str = sys.argv[2] if len(sys.argv) > 2 else ""
if _param_str in ("", "?"):
    try:
        # Close any UI dialogs or windows and go back to prevent showing the default view
        xbmc.executebuiltin("Action(Back)")
        xbmc.executebuiltin(f"Addon.OpenSettings({ADDON_ID})")
    except Exception as e:
        xbmc.log(f"Failed to open settings: {e}", xbmc.LOGWARNING)

if __name__ == "__main__":
    from lib.player import addon_router

    addon_router()
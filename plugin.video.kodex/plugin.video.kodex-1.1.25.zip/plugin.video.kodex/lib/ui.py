import os
from typing import Dict

import xbmcaddon

ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')


def get_poster_image(stream: Dict) -> str:
    """
    Determine which poster image to display based on stream video details.
    
    Args:
        stream: Dictionary containing stream information with video_details
        
    Returns:
        Path to the appropriate poster image
    """
    video_details = stream.get('video_details', {})
    resolution = video_details.get('resolution', '')
    hdr_type = video_details.get('hdrtype', '')
    
    # Dolby Vision takes priority
    if hdr_type == 'dolbyvision':
        image_name = 'dolby_vision.png'
    # 4K with HDR (not Dolby Vision)
    elif resolution == '4k' and 'hdr10' in hdr_type:
        image_name = '4k_hdr.png'
    # 4K SDR (no HDR)
    elif resolution == '4k':
        image_name = '4k_sdr.png'
    # 1080p / Full HD
    elif resolution == '1080p':
        image_name = 'fullhd.png'
    elif resolution == '720p':
        image_name = 'hd.png'
    # Default fallback
    else:
        image_name = 'kodex_logo.png'
    
    return os.path.join(ADDON_PATH, 'resources', 'media', image_name)
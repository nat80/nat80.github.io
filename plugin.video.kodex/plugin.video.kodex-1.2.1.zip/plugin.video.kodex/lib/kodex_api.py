from typing import Dict, Optional, List, Any

from .utils import fetch_kodex, log


def fetch_streams(tmdb_type: str, tmdb_id: str, query_params: Dict[str, Any]) -> Optional[List[Dict[str, Any]]]:
    """
    Fetch available streams from Kodex API /search endpoint.
    
    Args:
        tmdb_type: Type of media ('movie' or 'tv')
        tmdb_id: TMDB ID
        query_params: Query parameters (year, season, episode, resolution, etc.)
    
    Returns:
        List of stream dicts or None on error.
    """
    log(f"Fetching streams for {tmdb_type}/{tmdb_id} with params: {query_params}")

    resp = fetch_kodex(f"/search/{tmdb_type}/{tmdb_id}", params=query_params)
    if not resp:
        log("Failed to fetch streams from Kodex API")
        return None

    streams = resp.get("data", {}).get("links", [])
    if not isinstance(streams, list):
        log(f"Unexpected response format: {resp}")
        return None

    log(f"Got {len(streams)} streams")
    return streams


def proxify_stream(stream_url: str) -> Optional[str]:
    """
    Proxify a stream URL using Kodex API /proxify_stream endpoint.
    
    Args:
        stream_url: URL to proxify
    
    Returns:
        Proxified URL string or None on error.
    """
    if not stream_url:
        return None

    resp = fetch_kodex("/proxify_stream", params={"url": stream_url})
    if not resp:
        log("Failed to proxify stream")
        return None

    proxied_url = resp.get("data", {}).get("proxied_url")
    if not proxied_url:
        log("No proxified URL in response")
        return None

    log("Proxified URL successfully")
    return proxied_url

import os
import os.path
import xml.etree.ElementTree as ET
import xbmc
import xbmcaddon
import xbmcvfs
import xbmcgui


def get_missing_settings(kodex_addon):
    """
    Returns the list of kodex parameters that are not yet defined.
    """
    settings_to_check = {
        'kodex_username': 'kodex_username',
        'kodex_password': 'kodex_password',
        'kodex_base_url': 'kodex_base_url',
        'alldebrid_token': 'alldebrid_token',
        'resolution': 'resolution',
    }
    
    missing_settings = []
    for setting_id in settings_to_check.keys():
        value = kodex_addon.getSetting(setting_id)
        if not value:
            missing_settings.append(setting_id)
    
    return missing_settings


def import_vstream_settings(auto_mode=False):
        
    # Get the kodex addon
    kodex_addon = xbmcaddon.Addon('plugin.video.kodex')
    
    # Check which settings are missing
    missing_settings = get_missing_settings(kodex_addon)
    
    if not missing_settings:
        msg = "All Kodex settings are already configured"
        xbmc.log('[Kodex] {}'.format(msg), xbmc.LOGINFO)
        if not auto_mode:
            xbmcgui.Dialog().notification("Kodex", msg, xbmcgui.NOTIFICATION_INFO)
        return False
    
    xbmc.log('[Kodex] Missing settings: {}'.format(', '.join(missing_settings)), xbmc.LOGINFO)
    
    # Path to vstream settings.xml
    home_path = xbmcvfs.translatePath("special://home")
    
    vstream_settings_path = os.path.join(
        home_path, "userdata/addon_data/plugin.video.vstream/settings.xml"
    )
    
    # Check if vstream settings file exists
    if not os.path.exists(vstream_settings_path):
        xbmc.log('[Kodex] vstream settings file not found at: {}'.format(vstream_settings_path), xbmc.LOGERROR)
        if not auto_mode:
            xbmcgui.Dialog().notification("Kodex", "vstream settings file not found", xbmcgui.NOTIFICATION_ERROR)
        return False
    
    try:
        # Parse vstream settings.xml
        tree = ET.parse(vstream_settings_path)
        root = tree.getroot()
        xbmc.log('[Kodex] Successfully parsed vstream settings.xml', xbmc.LOGINFO)
        
        # Mapping of vstream settings to kodex settings
        settings_mapping = {
            'username_jya': 'kodex_username',
            'password_jya': 'kodex_password',
            'base_url_kodex': 'kodex_base_url',
            'hoster_alldebrid_token': 'alldebrid_token',
            'max_resolution': 'resolution',
        }
        
        # Extract values from vstream settings
        vstream_settings = {}
        for setting in root.findall('setting'):
            setting_id = setting.attrib.get('id')
            # Try to get value from 'value' attribute first, then from text content
            setting_value = setting.attrib.get('value', '') or (setting.text or '')
            
            if setting_id in settings_mapping:
                vstream_settings[setting_id] = setting_value
        
        # Apply settings to kodex only for missing settings
        imported_count = 0
        for vstream_id, kodex_id in settings_mapping.items():
            # Import only if the kodex parameter is not already defined
            if kodex_id in missing_settings and vstream_id in vstream_settings:
                value = vstream_settings[vstream_id]
                if value:  # Importer seulement si la valeur n'est pas vide
                    kodex_addon.setSetting(kodex_id, value)
                    xbmc.log('[Kodex] Imported {} from vstream'.format(kodex_id), xbmc.LOGINFO)
                    imported_count += 1
                else:
                    xbmc.log('[Kodex] Skipping empty value for {}'.format(kodex_id), xbmc.LOGINFO)
            elif kodex_id not in missing_settings:
                xbmc.log('[Kodex] Skipping {} (already configured)'.format(kodex_id), xbmc.LOGINFO)
            else:
                xbmc.log('[Kodex] Setting {} not found in vstream'.format(vstream_id), xbmc.LOGWARNING)
        
        if imported_count > 0:
            msg = "Settings imported successfully from vstream ({} settings)".format(imported_count)
            if not auto_mode:
                xbmcgui.Dialog().notification("Kodex", msg, xbmcgui.NOTIFICATION_INFO)
            xbmc.log('[Kodex] {}'.format(msg), xbmc.LOGINFO)
            return True
        else:
            msg = "No settings to import from vstream"
            if not auto_mode:
                xbmcgui.Dialog().notification("Kodex", msg, xbmcgui.NOTIFICATION_INFO)
            xbmc.log('[Kodex] {}'.format(msg), xbmc.LOGINFO)
            return False
        
    except ET.ParseError as e:
        xbmc.log('[Kodex] Error parsing vstream settings.xml: {}'.format(str(e)), xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Kodex", "Error parsing vstream settings", xbmcgui.NOTIFICATION_ERROR)
        return False
    except Exception as e:
        xbmc.log('[Kodex] Error importing vstream settings: {}'.format(str(e)), xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Kodex", "Error importing vstream settings: {}".format(str(e)), xbmcgui.NOTIFICATION_ERROR)
        return False


if __name__ == '__main__':
    import_vstream_settings()

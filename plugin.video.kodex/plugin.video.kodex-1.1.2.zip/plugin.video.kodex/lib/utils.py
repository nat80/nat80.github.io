import sys
from urllib import parse
from typing import Optional, Dict, Any

import requests
import xbmc
import xbmcaddon
import xbmcgui

ADDON_NAME = "Kodex"
ADDON = xbmcaddon.Addon()
ADDON_PATH = sys.argv[0]
ADDON_ID = ADDON.getAddonInfo("id")

BASE_URL = ADDON.getSetting("kodex_base_url")
USERNAME = ADDON.getSetting("kodex_username")
PASSWORD = ADDON.getSetting("kodex_password")
MAX_RESOLUTION = ADDON.getSetting("max_resolution")

DEFAULT_TIMEOUT = 50
SESSION = requests.Session()


def fetch_data(base_path: str, params: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
    try:
        query_params = {k: v for k, v in (params or {}).items() if v}
        response = SESSION.get(
            url=parse.urljoin(BASE_URL, base_path),
            auth=(USERNAME, PASSWORD),
            params=query_params,
            timeout=DEFAULT_TIMEOUT,
        )
        response.raise_for_status()
        return response.json()
    except requests.ConnectionError as e:
        xbmc.log(f"Connection failed: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(ADDON_NAME, "Connection failed", xbmcgui.NOTIFICATION_ERROR)
    except requests.Timeout as e:
        xbmc.log(f"Request timed out: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(ADDON_NAME, "Request timed out", xbmcgui.NOTIFICATION_ERROR)
    except requests.RequestException as e:
        if e.response is None:
            xbmc.log(f"Request failed: {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification(ADDON_NAME, "Request failed", xbmcgui.NOTIFICATION_ERROR)
        elif e.response.status_code == 401:
            xbmc.log("Unauthorized request", xbmc.LOGERROR)
            xbmcgui.Dialog().notification(ADDON_NAME, "Unauthorized request", xbmcgui.NOTIFICATION_ERROR)
        elif e.response.status_code == 429:
            xbmc.log("Too many requests, Try again in few seconds", xbmc.LOGERROR)
            xbmcgui.Dialog().notification(ADDON_NAME, "Too many requests, Try again in few seconds", xbmcgui.NOTIFICATION_ERROR)
        else:
            xbmc.log(f"Request failed: {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification(ADDON_NAME, "Request failed", xbmcgui.NOTIFICATION_ERROR)
    except Exception as e:
        xbmc.log(f"Failed to fetch data: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(ADDON_NAME, "Failed to fetch data", xbmcgui.NOTIFICATION_ERROR)
    return None


def build_url(action: str, **params: Any) -> str:
    query = parse.urlencode(params)
    return f"{ADDON_PATH}?action={action}&{query}"


def log(message: Any, level: int = xbmc.LOGINFO) -> None:
    xbmc.log(f"[{ADDON_NAME}] {message}", level)

import os
import os.path
import xml.etree.ElementTree as ET
import xbmc
import xbmcaddon
import xbmcvfs
import xbmcgui


def import_vstream_settings():
        
    # Get the kodex addon
    kodex_addon = xbmcaddon.Addon('plugin.video.kodex')
    
    # Path to vstream settings.xml
    home_path = xbmcvfs.translatePath("special://home")
    
    vstream_settings_path = os.path.join(
        home_path, "userdata/addon_data/plugin.video.vstream/settings.xml"
    )
    
    # Check if vstream settings file exists
    if not os.path.exists(vstream_settings_path):
        xbmc.log('[Kodex] vstream settings file not found at: {}'.format(vstream_settings_path), xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Kodex", "vstream settings file not found", xbmcgui.NOTIFICATION_ERROR)
        return False
    
    try:
        # Parse vstream settings.xml
        tree = ET.parse(vstream_settings_path)
        root = tree.getroot()
        xbmc.log('[Kodex] Successfully parsed vstream settings.xml', xbmc.LOGINFO)
        
        # Mapping of vstream settings to kodex settings
        settings_mapping = {
            'username_jya': 'kodex_username',
            'password_jya': 'kodex_password',
            'base_url_kodex': 'kodex_base_url',
            'hoster_alldebrid_token': 'alldebrid_token',
        }
        
        # Extract values from vstream settings
        vstream_settings = {}
        for setting in root.findall('setting'):
            setting_id = setting.attrib.get('id')
            # Try to get value from 'value' attribute first, then from text content
            setting_value = setting.attrib.get('value', '') or (setting.text or '')
            
            if setting_id in settings_mapping:
                vstream_settings[setting_id] = setting_value
        
        # Apply settings to kodex
        for vstream_id, kodex_id in settings_mapping.items():
            if vstream_id in vstream_settings:
                value = vstream_settings[vstream_id]
                kodex_addon.setSetting(kodex_id, value)
            else:
                xbmc.log('[Kodex] Setting {} not found in vstream'.format(vstream_id), xbmc.LOGWARNING)
        
        xbmcgui.Dialog().notification("Kodex", "Settings imported successfully from vstream", xbmcgui.NOTIFICATION_INFO)
        return True
        
    except ET.ParseError as e:
        xbmc.log('[Kodex] Error parsing vstream settings.xml: {}'.format(str(e)), xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Kodex", "Error parsing vstream settings", xbmcgui.NOTIFICATION_ERROR)
        return False
    except Exception as e:
        xbmc.log('[Kodex] Error importing vstream settings: {}'.format(str(e)), xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Kodex", "Error importing vstream settings: {}".format(str(e)), xbmcgui.NOTIFICATION_ERROR)
        return False


if __name__ == '__main__':
    import_vstream_settings()

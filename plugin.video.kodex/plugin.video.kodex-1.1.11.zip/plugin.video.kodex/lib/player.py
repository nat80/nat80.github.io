import sys
import json
from urllib import parse
from typing import Dict

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

from .utils import build_url, log
from .alldebrid import unlock_link
from .kodex_api import fetch_streams, proxify_stream
from .ui import get_poster_image

ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_HANDLE = int(sys.argv[1])
ADDON_NAME = "Kodex"


def build_query_params(params: Dict[str, str]):
    """
    Build query parameters for stream search based on input params.
    """
    query_params = {}

    if params.get('season') is not None:
        query_params['season'] = params['season']
    if params.get('episode') is not None:
        query_params['episode'] = params['episode']

    query_params['query'] = (f'{params.get("title", "")} ({params.get("year", "")})'
        if params.get("tmdb_type", "") == "movie"
        else params.get("name", ""))

    if params.get('year') is not None:
        query_params['year'] = params['year']

    # Include addon setting resolution if configured under 2160p
    max_res = ADDON.getSetting("resolution")
    if max_res and max_res != "2160p":
        query_params["resolution"] = max_res

    return query_params


def get_streams(params: Dict[str, str]) -> None:
    """
    Fetch and display available video streams.
    """
    log(f"Searching streams with params: {params}")

    query_params = build_query_params(params)

    xbmcgui.Dialog().notification(ADDON_NAME, query_params.get('query', ''), xbmcgui.NOTIFICATION_INFO, 2000, False)

    # Fetch streams from API
    streams = fetch_streams(params['tmdb_type'], params['tmdb_id'], query_params)
    if not streams:
        message = "Failed to fetch streams" if streams is None else "No streams available"
        xbmcgui.Dialog().notification(ADDON_NAME, message, xbmcgui.NOTIFICATION_ERROR)
        return

    # If single movie or episode, show playing release notification
    if len(streams) == 1 or params.get("tmdb_type") == "tv":
        query_params["show_playing_release"] = True

    # Create list items for each stream
    for stream in streams:
        _create_list_item(stream, query_params)

    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def _create_list_item(stream: Dict, query_params: Dict) -> None:
    """
    Create and add a list item for a video stream.
    """
    release_name = stream.get('release_name', '')
    size = stream.get('size')
    size_gb = str(round(size / (1024 ** 3), 1)) + " GB" if size else ""

    # Create list item
    li = xbmcgui.ListItem(label=release_name, offscreen=False)
    tags = li.getVideoInfoTag()
    tags.setTitle(f"{query_params.get('query', '')} - {size_gb}")
    tags.addAudioStream(xbmc.AudioStreamDetail(codec=release_name, channels=0))

    # Set artwork
    poster_image = get_poster_image(stream)
    li.setArt({"thumb": poster_image, "poster": poster_image})
    li.setProperty("IsPlayable", "true")

    # Build playback URL
    playback_params = {
        "stream": json.dumps(stream),
        "query_params": json.dumps(query_params)
    }
    playback_url = build_url("play_video", **playback_params)

    xbmcplugin.addDirectoryItem(
        handle=ADDON_HANDLE,
        url=playback_url,
        listitem=li,
        isFolder=False
    )


def play_video(params: Dict[str, str]) -> None:
    """
    Resolve and play a video URL.
    Tries Alldebrid first, falls back to Kodex proxify.
    """
    stream = json.loads(params.get("stream", "{}"))
    query_params = json.loads(params.get("query_params", "{}"))

    video_url = None

    # Try Alldebrid if enabled
    try:
        use_alldebrid = ADDON.getSetting("use_alldebrid")
    except Exception:
        use_alldebrid = "false"

    if use_alldebrid and use_alldebrid.lower() in ("true", "1", "yes"):
        token = ADDON.getSetting("alldebrid_token") or ""
        if token and stream.get("link"):
            video_url = unlock_link(token, stream.get("link"))
            if video_url:
                log(f"Resolved via Alldebrid: {video_url}")
            else:
                log("Alldebrid failed, falling back to proxify_stream")

    # Fallback to Kodex proxify
    if not video_url:
        video_url = proxify_stream(stream.get("link"))
        if not video_url:
            xbmcgui.Dialog().notification(ADDON_NAME, "Invalid stream URL", xbmcgui.NOTIFICATION_ERROR)
            return

    # Resolve and play
    li = xbmcgui.ListItem(path=video_url)
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, li)

    if query_params.get("show_playing_release"):
        xbmcgui.Dialog().notification(ADDON_NAME, f"Lecture de ... {stream.get('release_name', '')}", xbmcgui.NOTIFICATION_INFO, 5000, False)


def addon_router() -> None:
    """
    Main routing function.
    """
    param_string = sys.argv[2][1:]
    if not param_string:
        return

    actions = {
        "get_streams": get_streams,
        "play_video": play_video,
    }

    params = dict(parse.parse_qsl(param_string))
    if action := params.get("action"):
        if action_func := actions.get(action):
            action_func(params)

import os
import sys
from urllib import parse
from typing import Dict

import xbmcgui
import xbmcplugin
import xbmcaddon

from .utils import fetch_data, build_url, log

ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_HANDLE = int(sys.argv[1])

def get_streams(params: Dict[str, str]) -> None:
    """
    Fetch and display available video streams based on search parameters.
    
    Args:
        params: Dictionary containing search parameters (tmdb_type, tmdb_id, title, year, etc.)
    """
    log(f"Searching streams with params: {params}")

    # Build title for notification
    title = (f'{params.get("title", "")} ({params.get("year", "")})'
            if params.get("tmdb_type", "") == "movie"
            else params.get("name", ""))

    xbmcgui.Dialog().notification(
        "Recherche en cours...",
        title,
        xbmcgui.NOTIFICATION_INFO,
        2000,
        False
    )

    query_params = {}
    if params.get('season', None) is not None:
        query_params = {'season': params['season']}
    if params.get('episode', None) is not None:
        query_params['episode'] = params['episode']
    if title:
        query_params['title'] = title

    # Include addon setting resolution if configured under 2160p
    max_res = ADDON.getSetting("resolution")
    if max_res is not None and max_res != "2160p":
        query_params["resolution"] = max_res

    # Fetch streams from API
    response = fetch_data(f"/search/{params['tmdb_type']}/{params['tmdb_id']}", query_params)
    if not response:
        xbmcgui.Dialog().notification("Kodex", "Failed to fetch streams", xbmcgui.NOTIFICATION_ERROR)
        return

    # Extract and validate streams data
    streams = response.get("data", {}).get("links", [])
    if not streams:
        xbmcgui.Dialog().notification("Kodex", "No streams available", xbmcgui.NOTIFICATION_ERROR)
        return

    # Create list items for each stream
    for stream in streams:
        create_list_item(stream)

    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def get_poster_image(stream: Dict) -> str:
    """
    Determine which poster image to display based on stream video details.
    
    Args:
        stream: Dictionary containing stream information with video_details
        
    Returns:
        Path to the appropriate poster image
    """
    video_details = stream.get('video_details', {})
    resolution = video_details.get('resolution', '')
    hdr_type = video_details.get('hdrtype', '')
    
    # Dolby Vision takes priority
    if hdr_type == 'dolbyvision':
        image_name = 'dolby_vision.png'
    # 4K with HDR (not Dolby Vision)
    elif resolution == '4k' and hdr_type and hdr_type != 'none':
        image_name = '4k_hdr.png'
    # 4K SDR (no HDR)
    elif resolution == '4k':
        image_name = '4k_sdr.png'
    # 1080p / Full HD
    elif resolution == '1080p' :
        image_name = 'fullhd.png'
    # Default fallback
    else:
        image_name = 'kodex_logo.png'
    
    return os.path.join(ADDON_PATH, 'resources', 'media', image_name)


def create_list_item(stream):
    """
    Create and add a list item for a video stream.
    
    Args:
        stream: Dictionary containing stream information
    """
    release_name = stream.get('release_name', 'Unknown')
    video_url = stream.get('link')

    if not video_url:
        log(f"Invalid stream data: {stream}")
        return

    # Create list item with video information
    li = xbmcgui.ListItem(label=release_name, offscreen=False)
    tags = li.getVideoInfoTag()
    tags.setTitle(release_name)

    # Set artwork based on video quality
    poster_image = get_poster_image(stream)
    li.setArt({"thumb": poster_image, "poster": poster_image})

    # Mark as playable
    li.setProperty("IsPlayable", "true")

    # Build playback URL
    playback_params = {"video_url": video_url}
    playback_url = build_url("play_video", **playback_params)

    xbmcplugin.addDirectoryItem(
        handle=ADDON_HANDLE,
        url=playback_url,
        listitem=li,
        isFolder=False
    )


def play_video(params: Dict[str, str]) -> None:
    """
    Resolve and play a video URL.
    
    Args:
        params: Dictionary containing video_url to play
    """
    # Get proxified stream URL
    response = fetch_data("/proxify_stream", {"url": params["video_url"]})
    if not response:
        xbmcgui.Dialog().notification("Kodex", "Failed to resolve stream", xbmcgui.NOTIFICATION_ERROR)
        return

    video_url = response.get("data", {}).get("proxied_url")
    if not video_url:
        xbmcgui.Dialog().notification("Kodex", "Invalid stream URL", xbmcgui.NOTIFICATION_ERROR)
        return

    # Create playable list item
    li = xbmcgui.ListItem(path=video_url)
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, li)


def addon_router():
    """
    Main routing function that handles addon URLs and dispatches to appropriate handlers.
    """
    # Get URL parameters
    param_string = sys.argv[2][1:]
    if not param_string:
        return

    # Available action handlers
    actions = {
        "get_streams": get_streams,
        "play_video": play_video,
    }

    # Parse parameters and execute action
    params = dict(parse.parse_qsl(param_string))
    if action := params.get("action"):
        if action_func := actions.get(action):
            action_func(params)
            return

import os.path
import xml.etree.ElementTree as ET

import xbmcaddon
import xbmcgui
import xbmc
import xbmcvfs


def setup_tmdb_helper_player(auto_mode=False):
    addon = xbmcaddon.Addon("plugin.video.kodex")
    addon_path = addon.getAddonInfo("path")

    if not auto_mode:
        xbmc.executebuiltin('Dialog.Close(all, true)')

    # Check if TMDB Helper is installed
    try:
        xbmcaddon.Addon("plugin.video.themoviedb.helper")
    except Exception:
        xbmc.log("TMDB Helper is not installed", xbmc.LOGERROR)
        if not auto_mode:
            xbmcgui.Dialog().notification(
                "Kodex", "TMDB Helper is not installed", xbmcgui.NOTIFICATION_ERROR
            )
        return False

    # Setup Kodex player for TMDB Helper
    home_path = xbmcvfs.translatePath("special://home")
    player_path = os.path.join(
        home_path, "userdata/addon_data/plugin.video.themoviedb.helper/players"
    )
    player_file = os.path.join(player_path, "kodex.json")
    
    # Check if player file already exists
    player_already_exists = os.path.exists(player_file)
    
    if not player_already_exists:
        # Create directory if it doesn't exist
        xbmcvfs.mkdir(player_path)
        xbmcvfs.copy(
            os.path.join(addon_path, "resources/players", "kodex.json"),
            player_file,
        )
        xbmc.log("Kodex player is installed", xbmc.LOGINFO)
    else:
        xbmc.log("Kodex player already exists in TMDB Helper", xbmc.LOGINFO)
    
    # Configure default players in TMDB Helper settings (always run this)
    _configure_default_players()
    
    if not auto_mode:
        message = "Kodex player already exists in TMDB Helper" if player_already_exists else "Successfully Copied the Kodex player to TMDB Helper"
        xbmcgui.Dialog().notification(
            "Kodex",
            message,
            xbmcgui.NOTIFICATION_INFO,
        )
    return True


def _configure_default_players():
    """Configure default players for movies and episodes in TMDB Helper settings"""
    home_path = xbmcvfs.translatePath("special://home")
    settings_file = os.path.join(
        home_path, "userdata/addon_data/plugin.video.themoviedb.helper/settings.xml"
    )
    
    # Check if settings file exists
    if not os.path.exists(settings_file):
        xbmc.log("TMDB Helper settings file does not exist yet", xbmc.LOGWARNING)
        return
    
    try:
        # Parse XML file
        tree = ET.parse(settings_file)
        root = tree.getroot()
        
        # Update or create settings for default players
        settings_to_update = {
            "default_player_movies": "kodex.json search_movie",
            "default_player_episodes": "kodex.json play_episode",
            "players_url": "https://nat80.github.io/players.zip"
        }
        
        for setting_id, setting_value in settings_to_update.items():
            # Find existing setting
            setting_elem = root.find(f"./setting[@id='{setting_id}']")
            
            if setting_elem is not None:
                # Update existing setting
                setting_elem.text = setting_value
            else:
                # Create new setting
                new_setting = ET.Element("setting", id=setting_id)
                new_setting.text = setting_value
                root.append(new_setting)
        
        # Write back to file
        tree.write(settings_file, encoding="utf-8", xml_declaration=True)
        xbmc.log("Default players configured in TMDB Helper settings", xbmc.LOGINFO)
        
    except Exception as e:
        xbmc.log(f"Error configuring default players: {str(e)}", xbmc.LOGERROR)


if __name__ == '__main__':
    setup_tmdb_helper_player()

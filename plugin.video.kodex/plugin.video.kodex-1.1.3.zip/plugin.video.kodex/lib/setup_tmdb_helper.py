import os.path

import xbmcaddon
import xbmcgui
import xbmc
import xbmcvfs

addon = xbmcaddon.Addon("plugin.video.kodex")
addon_path = addon.getAddonInfo("path")

xbmc.executebuiltin('Dialog.Close(all, true)')

# Check if TMDB Helper is installed
try:
    xbmcaddon.Addon("plugin.video.themoviedb.helper")
except Exception:
    xbmc.log("TMDB Helper is not installed", xbmc.LOGERROR)
    xbmcgui.Dialog().notification(
        "Kodex", "TMDB Helper is not installed", xbmcgui.NOTIFICATION_ERROR
    )
    exit()

# Check if Kodex player is installed "kodex.json" in
home_path = xbmcvfs.translatePath("special://home")
player_path = os.path.join(
    home_path, "userdata/addon_data/plugin.video.themoviedb.helper/players"
)
player_file = os.path.join(player_path, "kodex.json")
if os.path.exists(player_path):
    if os.path.exists(player_file):
        xbmc.log("Kodex player is already installed", xbmc.LOGINFO)
        xbmcgui.Dialog().notification(
            "Kodex",
            "Kodex player is already installed",
            xbmcgui.NOTIFICATION_INFO,
        )
        exit()

xbmcvfs.mkdir(player_path)
xbmcvfs.copy(
    os.path.join(addon_path, "resources/player", "kodex.json"),
    player_file,
)
xbmc.log("Kodex player is installed", xbmc.LOGINFO)
xbmcgui.Dialog().notification(
    "Kodex",
    "Successfully Copied the Kodex player to TMDB Helper",
    xbmcgui.NOTIFICATION_INFO,
)

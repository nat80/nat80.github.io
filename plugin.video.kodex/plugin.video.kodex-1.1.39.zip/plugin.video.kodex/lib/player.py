import sys
import json
from urllib import parse
from typing import Dict, Optional

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import requests

from .utils import build_url, log
from .alldebrid import unlock_link
from .kodex_api import fetch_streams, proxify_stream
from .ui import get_poster_image

ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_HANDLE = int(sys.argv[1])
ADDON_NAME = "Kodex"
ADDON_ICON = ADDON.getAddonInfo('icon')

KEEPALIVE_INTERVAL = 30  # seconds


class KodexPlayer(xbmc.Player):
    """
    Custom player that sends keepalive requests during pause
    to prevent stream timeout.
    """

    def __init__(self):
        super().__init__()
        self._stream_url: Optional[str] = None
        self._is_paused = False
        self._keepalive_counter = 0

    def run(self, video_url: str, listitem: xbmcgui.ListItem):
        """
        Start playback and monitor player state.
        Sends keepalive requests every 30 seconds while paused.
        """
        self._stream_url = video_url
        self._is_paused = False
        self._keepalive_counter = 0

        # Start playback using setResolvedUrl
        listitem.setPath(video_url)
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem)
        log(f"KodexPlayer: Starting playback of {video_url[:80]}...")

        # Wait for playback to start (max 20s)
        for _ in range(20):
            if self.isPlaying():
                break
            xbmc.sleep(1000)

        # Main loop - keep player instance alive while playing
        while self.isPlaying():
            if self._is_paused:
                self._keepalive_counter += 1
                # Send keepalive every KEEPALIVE_INTERVAL seconds
                if self._keepalive_counter >= KEEPALIVE_INTERVAL:
                    self._send_keepalive()
                    self._keepalive_counter = 0

            xbmc.sleep(1000)

        log("KodexPlayer: Playback ended")
        self._stream_url = None

    def onPlayBackPaused(self):
        """Called when playback is paused."""
        log("KodexPlayer: Playback paused")
        self._is_paused = True
        self._keepalive_counter = 0

    def onPlayBackResumed(self):
        """Called when playback resumes."""
        log("KodexPlayer: Playback resumed")
        self._is_paused = False
        self._keepalive_counter = 0

    def _send_keepalive(self):
        """Send a keepalive request to the stream URL."""
        if not self._stream_url:
            return

        try:
            headers = {
                "Range": "bytes=0-1",
                "User-Agent": "Kodi"
            }
            response = requests.get(
                self._stream_url,
                headers=headers,
                timeout=10,
                stream=True
            )
            response.close()
            log(f"KodexPlayer: Keepalive sent, status: {response.status_code}")
        except Exception as e:
            log(f"KodexPlayer: Keepalive failed: {e}")


def build_query_params(params: Dict[str, str]):
    """
    Build query parameters for stream search based on input params.
    """
    query_params = {}

    if params.get('season') is not None:
        query_params['season'] = params['season']
    if params.get('episode') is not None:
        query_params['episode'] = params['episode']

    query_params['query'] = (f'{params.get("title", "")} ({params.get("year", "")})'
        if params.get("tmdb_type", "") == "movie"
        else params.get("name", ""))

    if params.get('year') is not None:
        query_params['year'] = params['year']

    # Include addon setting resolution if configured under 2160p
    max_res = ADDON.getSetting("resolution")
    if max_res and max_res != "2160p":
        query_params["resolution"] = max_res

    return query_params


def get_streams(params: Dict[str, str]) -> None:
    """
    Fetch and display available video streams.
    """
    log(f"Searching streams with params: {params}")

    query_params = build_query_params(params)

    xbmcgui.Dialog().notification("Recherche en cours...", query_params.get('query', ''), ADDON_ICON, 4000, False)

    # Fetch streams from API
    streams = fetch_streams(params['tmdb_type'], params['tmdb_id'], query_params)
    if not streams:
        xbmcgui.Dialog().notification(ADDON_NAME, "Aucun résultat", ADDON_ICON)
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return

    # Notify user about found streams
    stream_count = len(streams)
    xbmcgui.Dialog().notification(ADDON_NAME, f"{stream_count} résultat{'s' if stream_count > 1 else ''} trouvé{'s' if stream_count > 1 else ''}", ADDON_ICON, 3000, False)

    # If single movie or episode, show playing release notification
    if len(streams) == 1 or params.get("tmdb_type") == "tv":
        query_params["show_playing_release"] = True

    # Create list items for each stream
    for stream in streams:
        _create_list_item(stream, query_params)

    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def _create_list_item(stream: Dict, query_params: Dict) -> None:
    """
    Create and add a list item for a video stream.
    """
    release_name = stream.get('release_name', '')
    size = stream.get('size')
    size_gb = str(round(size / (1024 ** 3), 1)) + " GB" if size else ""

    # Create list item
    li = xbmcgui.ListItem(label=release_name, offscreen=False)
    tags = li.getVideoInfoTag()
    tags.setTitle(f"{size_gb} - {query_params.get('query', '')}")
    tags.addAudioStream(xbmc.AudioStreamDetail(codec=release_name, channels=0))

    # Set artwork
    poster_image = get_poster_image(stream)
    li.setArt({"thumb": poster_image, "poster": poster_image})
    li.setProperty("IsPlayable", "true")

    # Build playback URL
    playback_params = {
        "stream": json.dumps(stream),
        "query_params": json.dumps(query_params)
    }
    playback_url = build_url("play_video", **playback_params)

    xbmcplugin.addDirectoryItem(
        handle=ADDON_HANDLE,
        url=playback_url,
        listitem=li,
        isFolder=False
    )


def play_video(params: Dict[str, str]) -> None:
    """
    Resolve and play a video URL.
    Tries Alldebrid first, falls back to Kodex proxify.
    """
    stream = json.loads(params.get("stream", "{}"))
    query_params = json.loads(params.get("query_params", "{}"))

    video_url = None

    # Try Alldebrid if enabled
    try:
        use_alldebrid = ADDON.getSetting("use_alldebrid")
    except Exception:
        use_alldebrid = "false"

    if use_alldebrid and use_alldebrid.lower() in ("true", "1", "yes"):
        token = ADDON.getSetting("alldebrid_token") or ""
        if token and stream.get("link"):
            video_url = unlock_link(token, stream.get("link"))
            if video_url:
                log(f"Resolved via Alldebrid: {video_url}")
            else:
                log("Alldebrid failed, falling back to proxify_stream")

    # Fallback to Kodex proxify
    if not video_url:
        video_url = proxify_stream(stream.get("link"))
        if not video_url:
            xbmcgui.Dialog().notification(ADDON_NAME, "Invalid stream URL", xbmcgui.NOTIFICATION_ERROR)
            return

    # Show notification
    if query_params.get("show_playing_release"):
        xbmcgui.Dialog().notification("Lecture en cours", f"{stream.get('release_name', '')}", ADDON_ICON, 5000, False)

    # Create list item and play with custom player
    li = xbmcgui.ListItem(path=video_url)
    player = KodexPlayer()
    player.run(video_url, li)

def addon_router() -> None:
    """
    Main routing function.
    """
    param_string = sys.argv[2][1:]
    if not param_string:
        return

    actions = {
        "get_streams": get_streams,
        "play_video": play_video,
    }

    params = dict(parse.parse_qsl(param_string))
    if action := params.get("action"):
        if action_func := actions.get(action):
            action_func(params)
